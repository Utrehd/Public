/*___Generated_by_IDEA___*/

package com.makeblock.xystage;

/* This stub is for using by IDE only. It is NOT the Manifest class actually packed into APK */
public final class Manifest {
}