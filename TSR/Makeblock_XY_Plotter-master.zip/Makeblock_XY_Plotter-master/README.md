Makeblock_XY_Plotter
====================

Here are the resources for the Makeblock XY Plotter Kit: http://makeblock.cc/xy-plotter-e-kit/

The detail stepps on how to build this ploter is here: http://www.instructables.com/id/How-to-make-a-XY-plotter-with-Makeblock/

We provide demo programs for controling the plotter by Android smart phone. An arduino code running on the arduino boards and
App Running on the smart phone are needed.

Plotter_For_Arduino.ino is the code for Arduino, you may need to add the latest Makeblock Library(https://github.com/Makeblock-official/Makeblock-Library) and AccelStepper Library to your Local Arduino library path.

You may need to install the XY_Plotter.apk on your smart phone. then, the plotter can draw the pictures send by your smart phone.

The description of the app is here: http://forum.makeblock.cc/t/xy-plotter-application-for-andoid/228

